# -*- coding: utf-8 -*-
"""
Created on Mon Jan 29 11:20:37 2018

@author: gwatmoug
"""

def bSearch(key, mylist, left, right):
    if (left >= right):
        return -1
    mid = (left+right)//2
    sm = mylist[mid]
    print ('search now centred at:{} '.format(sm))
    
    if (sm < key):
        print ("  moving search to right")
        return bSearch(key, mylist, mid+1, right)
    elif (sm > key):
        print ("  moving search to left")
        return bSearch(key, mylist, left, mid)
    else:
        return mid
   