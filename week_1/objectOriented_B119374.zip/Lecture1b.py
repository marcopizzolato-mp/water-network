from PointHandler import rand_PointField
from PointPlotter import PointPlotter
import time

def displayPointField(pointPlotter, pointField):
    pointPlotter.PointFieldScatter(pointField,"red")

    pl=pointField.getPoints()

    for i in range(len(pl)-1): 
        pointPlotter.plotVector(pl[i], pl[i+1],"yellow")
    
    pointPlotter.show()
 
  
xlo=0.0
xhi=1000.0
ylo=0.0
yhi=1000.0
num=20

print ("Point sorting")

## the function rand_PointFileds generates a random set of points
## pf is an instance of the class PointField -> Object with a list of point 2D in it
pf=rand_PointField(num, xlo, xhi, ylo, yhi)
pp=PointPlotter()
pp.set_axis(xlo, xhi, ylo, yhi)
## display the random set of points
displayPointField(pp, pf)

## I want to sort the random set of points generated above
## I need to add the method sortpoint in the class PointField - file Ponts.py
t=time.clock()
pfX = pf.sortPoints('X')
t1=round(time.clock()-t,5)

t=time.clock()
pfY = pf.sortPoints('Y')
t2=round(time.clock()-t,5)

## Test of the in-built functions sort located in the class PointField - file Ponts.py
t=time.clock()
pfX2 = pf.sortPoints2('X')
t3=round(time.clock()-t,8)

t=time.clock()
pfY2 = pf.sortPoints2('Y')
t4=round(time.clock()-t,8)

## display the sorted set of points
displayPointField(pp, pfX)
#displayPointField(pp, pfX2)
displayPointField(pp, pfY)

#Display the results of the time comparison
print ("Sorting by X {} took {}".format(num, t1))
print ("Sorting by Y {} took {}".format(num, t2))
print ("Sorting by X with in built function {} took {}".format(num, t3))
print ("Sorting by Y with in built function {} took {}".format(num, t4))